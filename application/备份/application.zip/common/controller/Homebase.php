<?php
namespace app\common\controller;
use app\common\controller\Base;
/**
 * Home基类控制器
 */
class Homebase extends Base{
	/**
	 * 初始化方法
	 */
	public function _initialize(){
		parent::_initialize();

	}




}

